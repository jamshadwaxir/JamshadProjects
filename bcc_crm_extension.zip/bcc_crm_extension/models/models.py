from odoo import models, fields, api
from odoo.exceptions import UserError
from odoo.osv.expression import expression


class CrmExtension(models.Model):
    _inherit = 'crm.lead'

    sale_order_ids = fields.Many2many('sale.order', string='Sale Orders')
    delivery_date = fields.Date(string='Delivery Date')
    invoice_residual = fields.Monetary(string='Invoice Amount', currency_field='company_currency')

    invoice_residual_total = fields.Monetary(string='Total Invoice Amount', compute='_compute_invoice_residual_total',
                                             store=True, currency_field='company_currency')

    @api.depends('invoice_residual')
    def _compute_invoice_residual_total(self):
        for lead in self:
            total_residual = 0.0

            lead.invoice_residual_total += total_residual

    @api.onchange('stage_id')
    def onchange_method(self):
        for rec in self:
            if rec.stage_id == 'En attente de paiement':
                rec.invoice_residual = rec.invoice_ids.amount_residual

    def new_quotation_order(self):
        # invoice = self.env['account.move'].search([])
        # for rec in invoice:
        #     self.invoice_residual = rec.amount_residual
        customer_name = self.contact_name if self.contact_name else self.partner_id.name
        return {
            'type': 'ir.actions.act_window',
            'name': 'New Quotation',
            'res_model': 'sale.order',
            'view_mode': 'form',
            'ref_id': 'sale_crm.sale_action_quotations_new',
            'target': 'current',
            'context': {
                'active_test': False,
                'default_partner_id': self.partner_id.id,
                'default_partner_id.name': customer_name,
                'default_expected_revenue': self.expected_revenue,
                'default_delivery_date': self.delivery_date,
                'default_opportunity_id': self.id,
            },
        }

    def sale_order(self):
        order_action = self.action_view_sale_order()
        return order_action

    def unlink(self):
        for record in self:
            if (record.stage_id.name == 'Clients' or
                    record.stage_id.name == 'Bon de commande' or
                    record.stage_id.name == 'En livraison' or
                    record.stage_id.name == 'En attente de paiement'):
                raise UserError("You cannot delete the records")
        return super(CrmExtension, self).unlink()
