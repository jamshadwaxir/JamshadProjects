from odoo import api, fields, models


class PartnerModel(models.Model):
    _inherit = 'res.partner'

    payment_term_id = fields.Many2one('account.payment.term', default=lambda self: self._get_default_payment_term(),
                                      store=True)

    property_payment_term_id = fields.Many2one('account.payment.term', company_dependent=True,
                                               string='Customer Payment Terms',
                                               help="This payment term will be used instead of the default one for sales orders and customer invoices",
                                               default=lambda self: self._get_default_payment_term())

    related_select_group = fields.Many2one('select.group',string='Group')

    def _get_default_payment_term(self):
        # Here you can implement your logic to find the default payment term
        payment_term = self.env['account.payment.term'].search([('name', '=', '15 Days')], limit=1)
        return payment_term.id if payment_term else False


# Class For Select Group Field
class SelectGroup(models.Model):
    _name = 'select.group'
    _description = 'SelectGroup'

    name = fields.Char(string='Group')


