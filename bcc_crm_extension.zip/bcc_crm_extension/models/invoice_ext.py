from odoo import api, fields, models


class ExtendInvoiceModel(models.Model):
    _inherit = 'account.move'
    _description = 'ExtendInvoieModel'

    crm_rel = fields.Many2one('crm.lead')
    sale_rel = fields.Many2one('sale.order')

    @api.model
    def default_get(self, fields_list):
        res = super(ExtendInvoiceModel, self).default_get(fields_list)
        default_crm_lead = self.env['crm.lead'].search([], limit=1)
        if default_crm_lead:
            res.update({'crm_rel': default_crm_lead.id})
        return res

    def action_post(self):
        # Call the super method to post the invoice
        result = super(ExtendInvoiceModel, self).action_post()
        if self.move_type == 'out_invoice':
            # Redirect to CRM Lead if it's a sales invoice
            self.crm_rel.stage_id = self.crm_rel.stage_id.search([('name', '=', 'En attente de paiement')]).id
            return {
                'type': 'ir.actions.act_window',
                'name': 'CRM Lead',
                'res_model': 'crm.lead',
                'view_mode': 'kanban,tree',
                'target': 'current',
            }

        elif self.move_type == 'in_invoice':
            # self.purchase_id.stages = self.env.ref('bcc_purchase_ext.stage_data_4').id
            return {
                'type': 'ir.actions.act_window',
                'name': 'Confirm Bill',
                'res_model': 'purchase.order',
                'view_mode': 'kanban,form,tree',
                'target': 'current'
            }