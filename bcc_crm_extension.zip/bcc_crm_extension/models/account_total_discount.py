from odoo import api, fields, models


class AccountInvoice(models.Model):
    """This class inherits "account.move" model and adds discount_type,
    discount_rate, amount_discount
     """
    _inherit = "account.move"

    discount_type = fields.Selection(
        [('percent', 'Percentage'), ('amount', 'Amount')],
        string='Discount type',
        default='percent', help="Type of discount.")
    discount_rate = fields.Float('Discount Rate', digits=(16, 2),
                                 help="Give the discount rate.")
    amount_discount = fields.Monetary(string='Discount', store=True,
                                      compute='_compute_amount_discount', readonly=True,
                                      help="Give the amount to be discounted.")

    total_after_discount = fields.Monetary(string='Total After Discount', readonly=True,
                                           compute='_compute_total_after_discount')

    amount_total_id = fields.Float(string='Total Of Tax Excl', compute='_compute_amount_total_without_discount', store=True)

    @api.depends('invoice_line_ids.tax_excl')
    def _compute_amount_total_without_discount(self):
        for rec in self:
            sum_tax_excl = 0
            for line in rec.invoice_line_ids:
                sum_tax_excl += line.tax_excl
            rec.amount_total_id = sum_tax_excl

    @api.depends('amount_discount', 'amount_total')
    def _compute_total_after_discount(self):
        for rec in self:
            rec.total_after_discount = rec.amount_total_id - rec.amount_discount

    @api.depends('discount_type', 'discount_rate', 'invoice_line_ids')
    def _compute_amount_discount(self):
        for inv in self:
            discount_totals = 0.0
            if inv.discount_type == 'percent':
                for line in inv.invoice_line_ids:
                    discount_total = (line.price_unit * line.quantity) * (inv.discount_rate / 100)
                    discount_totals += discount_total
            else:
                discount_totals = inv.discount_rate
            inv.amount_discount = discount_totals

    @api.onchange('discount_type', 'discount_rate', 'invoice_line_ids')
    def _supply_rate(self):
        """This function calculates supply rates based on change of
        discount_type, discount_rate and invoice_line_ids"""
        for inv in self:
            if inv.discount_type == 'percent':
                for line in inv.invoice_line_ids:
                    line.discount = inv.discount_rate
            else:
                total = sum(line.quantity * line.price_unit for line in inv.invoice_line_ids)
                if total:
                    discount = (inv.discount_rate / total) * 100
                else:
                    discount = inv.discount_rate
                for line in inv.invoice_line_ids:
                    line.discount = discount

    def button_dummy(self):
        """The button_dummy method is intended to perform some action related
        to the supply rate and always return True"""
        self._supply_rate()
        return True


class InheritAccountMoveLine(models.Model):
    _inherit = 'account.move.line'
    _description = 'InheritAccountMoveLine'

    tax_excl = fields.Float(string='Tax excl.', compute='_compute_tax_excl', store=True)

    @api.depends('quantity', 'price_unit')
    def _compute_tax_excl(self):
        for rec in self:
            rec.tax_excl = rec.quantity * rec.price_unit
