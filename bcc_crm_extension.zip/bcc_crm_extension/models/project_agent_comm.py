from odoo import fields, models, _
from datetime import datetime


class ProjectAgentComm(models.Model):
    _inherit = 'project.task'
    _description = ''

    user = fields.Many2one('res.users', string="Select User")
    message = fields.Text(string='Message')

    def send_message_to_user(self):
        model_id = self.env['ir.model'].search([
            ('name', '=', 'project.task')

        ])
        # self.message_post('Hi')
        notification_ids = [(0, 0,
                             {
                                 'res_partner_id': self.user.partner_id.id,
                                 'notification_type': 'inbox'
                             }
                             )]

        self.env['mail.message'].create({
            'message_type': "notification",
            'body': self.message,
            'subject': self.name,
            'partner_ids': [(4, self.user.partner_id.id)],
            'model': self._name,
            'res_id': self.id,
            'notification_ids': notification_ids,
            'author_id': self.env.user.partner_id and self.env.user.partner_id.id
        })

        # for task in self:
        #     if task.user and task.message:
        #         # Format the message_postessage to include the selected user's information
        #         formatted_message = f"Message from {task.user.name}:\n{task.message}"
        #         # Use Odoo's messaging framework to create and send a message
        #         task.message_post(
        #             body=formatted_message,
        #             partner_ids=[task.user.partner_id.id],
        #             message_type='notification'
        #         )
        #         # Optionally, you can add logic to reset the message field
        #         task.message = ''
        #
        #     return {
        #         'type': 'ir.actions.client',
        #         'tag': 'display_notification',
        #         'params': {
        #             'title': _("See New Notification"),
        #             'message': _("The new message will send to the agent."),
        #             'sticky': True,
        #         }
        #     }
