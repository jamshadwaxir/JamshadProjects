from datetime import timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError

import logging

_logger = logging.getLogger(__name__)


class SaleOrderExtend(models.Model):
    _inherit = 'sale.order'
    _description = 'sale_order'

    check = fields.Boolean(compute='_compute_allowed_invoice')
    delivery_date = fields.Date(string='Delivery Date', store=True)
    validity_date = fields.Date(string="Validity Date", required=True)
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string="Payment Terms",
        related='partner_id.property_payment_term_id',
        store=True, default="15 Days")

    def _compute_allowed_invoice(self):
        for rec in self:
            rec.check = rec.picking_ids.allowed_invoice

    @api.onchange('validity_date')
    def _onchange_validity_date(self):
        if self.validity_date:
            original_validity_date = fields.Date.from_string(self.validity_date)
            updated_validity_date = original_validity_date + timedelta(days=2)
            self.validity_date = updated_validity_date.strftime('%Y-%m-%d %H:%M:%S')
            self.payment_term_id = self.partner_id.payment_term_id

    def action_confirm(self):
        change_stage = super(SaleOrderExtend, self).action_confirm()
        self.opportunity_id.stage_id = self.opportunity_id.stage_id.search([('name', '=', 'Bon de commande')]).id
        return {
            'type': 'ir.actions.act_window',
            'name': 'New Quotation',
            'res_model': 'crm.lead',
            'view_mode': 'kanban,tree',
            'target': 'current',
            'context': {
            },
        }


class StockPickingExt(models.Model):
    _inherit = 'stock.picking'
    _description = 'StockPickingExt'

    allowed_invoice = fields.Boolean("Invoice  Allowed")
    crm_relation = fields.Many2one('crm.lead')

    @api.model
    def default_get(self, fields_list):
        res = super(StockPickingExt, self).default_get(fields_list)
        default_crm_lead = self.env['crm.lead'].search([], limit=1)
        if default_crm_lead:
            res.update({'crm_relation': default_crm_lead.id})
        return res

    def button_validate(self):
        # Check if the current record is related to a Sale Order
        if self.sale_id:
            rec = super(StockPickingExt, self).button_validate() #this is validate button
            self.allowed_invoice = True
            self.state = 'done'
            self.crm_relation.stage_id = self.crm_relation.stage_id.search([('name', '=', 'En livraison')]).id
            return {
                'type': 'ir.actions.act_window',
                'name': 'New Quotation',
                'res_model': 'crm.lead',
                'view_mode': 'kanban,tree',
                'target': 'current',
                'context': {},
            }

        # If not related to a Sale Order, just call the super method
        return super(StockPickingExt, self).button_validate()

    # def create_invoices(self):
    #     # Your custom logic to create invoices
    #     for order in self:
    #         # Example logic: create invoices
    #         order.action_invoice_create()