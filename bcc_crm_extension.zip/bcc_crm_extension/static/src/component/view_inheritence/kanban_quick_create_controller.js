/** @odoo-module **/

import { KanbanQuickCreateController } from '@web/views/kanban/kanban_quick_create_controller';
import { patch } from '@web/core/utils/patch';

patch(KanbanQuickCreateController.prototype, 'crm_extension.CustomKanbanQuickCreateController', {
    async addRecord() {
        await this.validate('add');
        this.cancel(true); // This will close the form after adding the record
    },
});
