# -*- coding: utf-8 -*-
{
    'name': "Bcc Crm Extension",
    'summary': "This module is used to extend the CRM Module",
    'description': """This module extends the CRM Module with additional features and customizations.""",
    'author': "My Company",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'crm', 'sale', 'stock', 'project', 'mail', 'bus'],
    'data': [
        # Security and access control
        'security/ir.model.access.csv',
        # Views
        'views/views.xml',
        'views/project_agent_comm.xml',
        'views/sale_changes.xml',
        'views/partner_ext.xml',
        'views/invoice_ext.xml',
        'views/account_total_discount.xml',
        'views/Delivery_report.xml',
        'views/invoice_report_ext.xml',
    ],
    # 'assets': {
    #     'web.assets_backend': [
    #         'crm_extension/static/src/component//*/*.js',
    #         'crm_extension/static/src/component//*/*.xml',
    #     ],
    # },
    'installable': True,
    'application': True,
}
