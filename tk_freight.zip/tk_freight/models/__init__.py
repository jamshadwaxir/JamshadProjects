# -*- coding: utf-8 -*-
# Copyright 2020 - Today Techkhedut.
# Part of Techkhedut. See LICENSE file for full copyright and licensing details.
from . import freight_bookings
from . import freight_dashboard
from . import freight_shipment
from . import freight_configuration
from . import freight_quot
from . import res_config
